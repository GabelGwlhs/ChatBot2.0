import java.util.Scanner;

public class Bot2Tester
{
    public static void main(String[] args) {

    
       Scanner input = new Scanner (System.in);
       System.out.print("Hello. What is your name? ");
       String names = input.nextLine();
       Bot2 bot1 = new Bot2(names);
       bot1.greeting();
       System.out.println("What is your favorite animal?");
       String animal = input.nextLine();
       bot1.favoriteAnimal(animal);
       System.out.println("Where do you live?");
       String location = input.nextLine();
       bot1.home(location);
       System.out.println("What is your favorite number?");
       int fav = input.nextInt();
       bot1.favoriteNumber(fav);
       bot1.goodbye();
       
       
    }
}